package com.example.learnig_call_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
